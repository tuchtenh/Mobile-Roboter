//
// You received this file as part of Finroc
// A framework for intelligent robot control
//
// Copyright (C) AG Robotersysteme TU Kaiserslautern
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
//
//----------------------------------------------------------------------
/*!\file    projects/rc_unimog_control_image_detection/mImageClassifier.h
 *
 * \author  Manuel Vogel
 *
 * \date    2020-12-07
 *
 * \brief Contains mImageClassifier
 *
 * \b mImageClassifier
 *
 * this is used to classify the images
 *
 */
//----------------------------------------------------------------------
#ifndef __projects__rc_unimog_control_image_detection__mImageClassifier_h__
#define __projects__rc_unimog_control_image_detection__mImageClassifier_h__

#include "plugins/structure/tSenseControlModule.h"
#include "libraries/machine_learning_appliance/mOpenCVTensorflowWrapper.h"
#include "libraries/object_detection/tDarknetYOLO.h"
#include "rrlib/geometry/tBoundingBox.h"
#include "rrlib/machine_learning_appliance/tMLDetection.h"

#include "rrlib/coviroa/tImage.h"
#include <vector>
#include "plugins/ib2c/tPercept.h"
//#include <opencv2/core.hpp>
#include <darknet.h>

//----------------------------------------------------------------------
// External includes (system with <>, local with "")
//----------------------------------------------------------------------

//----------------------------------------------------------------------
// Internal includes with ""
//----------------------------------------------------------------------

//----------------------------------------------------------------------
// Namespace declaration
//----------------------------------------------------------------------
namespace finroc
{
namespace rc_unimog_control_image_detection
{

//----------------------------------------------------------------------
// Forward declarations / typedefs / enums
//----------------------------------------------------------------------
enum class tDarknetUnimogClass
{
  eSTOP = 0,
  eSIGN1,
  eSIGN2,
  eCONES,
  eUNIMOG
};
using tDarknetDetection = rrlib::machine_learning_appliance::tMLDetection2D<tDarknetUnimogClass>;

//----------------------------------------------------------------------
// Class declaration
//----------------------------------------------------------------------
//! SHORT_DESCRIPTION
/*!
 * this is used to classify the images
 */
class mImageClassifier : public structure::tSenseControlModule
{

//----------------------------------------------------------------------
// Ports (These are the only variables that may be declared public)
//----------------------------------------------------------------------
public:

  tSensorInput<std::vector<rrlib::coviroa::tImage>> in_images;
  tSensorOutput<rrlib::coviroa::tImage> out_image; //for the classifier

  //tControllerOutput<rrlib::geometry::tPoint<2, float> point;

  //tCertaintyOutput<rrlib::coviroa::tImages, ib2c::tDynamicMatrixSigma> out_images; //for darknet yolo

    /*

  tStaticParameter<double> static_parameter_1;   Example for a static parameter. Replace or delete it!
  
  tParameter<double> par_parameter_1;   Example for a runtime parameter named "Parameter 1. Replace or delete it!

  tSensorInput<double> si_signal_1;   Example for sensor input ports named "Signal 1" and "Signal 2". Replace or delete them!
  tSensorInput<double> si_signal_2;

  tSensorOutput<double> so_signal_1;   Examples for a sensor output port named "Signal 1". Replace or delete them!

  tControllerInput<double> ci_signal_1;   Example for controller input ports named "Signal 1" and "Signal 2". Replace or delete them!
  tControllerInput<double> ci_signal_2;

  tControllerOutput<double> co_signal_1;   Examples for a controller output port named "Signal 1". Replace or delete them!
*/
//----------------------------------------------------------------------
// Public methods and typedefs
//----------------------------------------------------------------------
public:

  mImageClassifier(core::tFrameworkElement *parent, const std::string &name = "ImageClassifier");

//----------------------------------------------------------------------
// Protected methods
//----------------------------------------------------------------------
protected:

  /*! Destructor
   *
   * The destructor of modules is declared protected to avoid accidental deletion. Deleting
   * modules is already handled by the framework.
   */
  virtual ~mImageClassifier();

//----------------------------------------------------------------------
// Private fields and methods
//----------------------------------------------------------------------
private:

  network * nw_;
  layer l_;
  float nms_ = 0.4;
  image **alphabet_;
  float threshold = 0.3f;
  const std::string unimog_config = "/home/m_vogel/Downloads/yolov4-tiny.cfg";
  const std::string unimog_weights = "/home/m_vogel/Downloads/yolov4-tiny_last.weights";
  int classCount = 5;
  detection *dets = nullptr;


  virtual void OnStaticParameterChange() override;  // Might be needed to process static parameters. Delete otherwise!

  virtual void OnParameterChange() override;   //Might be needed to react to changes in parameters independent from Update() calls. Delete otherwise!

  virtual void Sense() override;

  virtual void Control() override;

};

//----------------------------------------------------------------------
// End of namespace declaration
//----------------------------------------------------------------------
}
}



#endif
